﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Hello_World
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int idade = 60;
            string numero1 = " Feliz natal ";
            Console.Write(String.Concat(Enumerable.Repeat(numero1, 20))); //Console.Write mostra conteudo na tela, igual um print

            int segundaGuerraMundial = 1942;
            segundaGuerraMundial = segundaGuerraMundial + 20;
            float velocidadeCarroF1 = 250.41f;
            Console.Write(segundaGuerraMundial + numero1 + velocidadeCarroF1);

            //APRENDENDO A ESTRUTURA ELSE IF
            if (idade >= 18 && idade < 45)
            {
                Console.WriteLine(" Você é maior de idade");
            }
            else if (idade >= 44) 
            {
                Console.WriteLine(" CARAMBA, você já está idoso");
            }
            else
            {
                Console.WriteLine(" Você é menor de idade");
            }


            //APRENDE COMO ARMAZENAR O QUE O USUARIO DIGITAR

            Console.WriteLine("Digite seu nome: ");
            string nome = Console.ReadLine();
            Console.Write(nome);

            Console.WriteLine(" Digite seu sobrenome: ");
            string nome1 = Console.ReadLine();
            

            Console.WriteLine($"Olá, {nome} {nome1}");
        }
    }
}
